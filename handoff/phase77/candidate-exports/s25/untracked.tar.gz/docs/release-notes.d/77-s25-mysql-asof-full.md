### MySQL ASOF JOIN beside FULL JOIN

Single-file MySQL emission now composes the existing backward `asof left join`
or `asof inner join` lowering with its existing `FULL JOIN` derived-table
emulation. An ASOF after a FULL reads the derived ports; one before a FULL is
rendered in each required `UNION ALL` branch. The latest-row ordering,
source-occurrence multiplicity, and the right-only FULL branch's `IS NULL`
test are unchanged. PostgreSQL, parser, semantic facts, IR, project emission,
and the existing ASOF grammar are unchanged.

This is a source candidate only: qualified native MySQL execution and the
two-database differential are still pending. It makes no native-execution or
release claim, and project FULL/ASOF combinations remain outside this slice.
