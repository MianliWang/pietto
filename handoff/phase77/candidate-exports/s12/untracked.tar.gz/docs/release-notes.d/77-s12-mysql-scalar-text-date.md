### MySQL project scalar text and date candidates

MySQL project emission has candidate forms for `concat`, non-truncating
`lpad`, non-conditional `add_months`, and statement-UTC `now()`. The candidate
preserves every repeated `lpad` argument occurrence in native placeholder
order. Conditional Date/month inputs remain refused, and no native result or
qualification claim is made until the scheduled target campaign.
