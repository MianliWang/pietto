### MySQL project conditional count and group tests

`emit-sql --project` can emit `sum(1 for o in group if test)`,
`any(test for o in group)` and `all(test for o in group)` for MySQL with the
same `COUNT(CASE ...)` meanings as the existing single-file and PostgreSQL
forms. The candidate keeps a non-null signed-64 count and non-null computed
Bool carrier. It does not open conditional `sum(Int)`, aggregate windows, or
any unreviewed target family.

This fragment remains candidate evidence until the frozen PostgreSQL/MySQL
campaign accepts the emitted SQL, parameters, physical metadata and raw rows.
